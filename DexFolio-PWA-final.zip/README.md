# Dexfolio — Pokémon Collector

Professional dark-mode, bilingual (Português/English), mobile-first collector app prototype.

## Included
- Pokédex loads all 1,025 Pokémon from PokéAPI.
- Pokémon sprites use the Generation V Black/White animated pixel-art sprite set, with a pixel-art static sprite fallback.
- Pokédex progress counter shows the number registered out of 1,025 on the dashboard.
- Scarlet & Violet and Mega Evolution block set list, using original English set names.
- Set logos are loaded from Pokémon TCG API when available, with image fallback URLs.
- Binder inventory with quantity, duplicates, set name, and card number.
- Add custom sets and cards; localStorage persistence; JSON backup export.
- Portuguese and English interface.
- PWA manifest and offline shell cache.

## Important limitations
- This is an installable PWA prototype, not a compiled native APK.
- First load requires internet to fetch the full Pokédex and set logos. Pokémon data is provided by PokéAPI and set information/logos by Pokémon TCG API.
- Set list is curated to Scarlet & Violet and Mega Evolution releases available through October 2026. The newest future release not yet launched as of October 22, 2026 is not listed as released.
- Card ownership and progress are stored in the browser on the current device. Export the JSON backup before clearing browser data. Cloud sync is not included.
- Set totals are catalogue/collector totals and can differ by language or counting of secret cards; verify the local set checklist against the exact card language you collect.

## Install on Android
1. Host the contents of this folder at an HTTPS address (for example GitHub Pages or Netlify).
2. Open the URL in Chrome on Android.
3. Choose Chrome menu → Install app / Add to Home screen.

For an actual native APK, the next step is to port the interface to Kotlin/Jetpack Compose or package the web app using a trusted Android wrapper.


## Latest update
- Pokédex presented as a 3-column by 4-row binder page (12 Pokémon per page), with previous/next arrows. At 1,025 entries, the full list spans 86 pages.
- Registration updates the selected Pokémon card in place to avoid rebuilding all sprites on every click.
- Language button now displays the active language (PT for Portuguese, EN for English).
